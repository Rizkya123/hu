@include('HeaderFooter')

<!-- /. NAV SIDE  -->
<div id="page-wrapper" >
<div id="page-inner">
<div class="row">
<div class="col-md-12">
	<h1 class="page-header">Information Pegawai<small> Revolution Employee</small>
    </h1>
</div>
</div>

<!-- /. ROW  -->
<div class="row">
<div class="col-md-12">
<div class="panel panel-default">
<div class="panel-heading">Information</div>
<div class="panel-body">
<div class="panel-group" id="accordion">

@foreach($data_pegawai as $p)

	<a href="/DataPegawai" class="btn btn-warning"> Back</a>
	
	<a href="/PrintInfoPegawai/{{ $p->id }}" class="btn btn-primary" target="_BLANK"><i class="fa fa-fw fa-file"></i>Print Halaman</a>

	<br></br>

	<form action="/CekInfoGaji/{{ $p->nip }}">
		<button class="btn btn-success">
			<i class="fa fa-fw fa-money"></i> Cek Info Gaji
		</button>
	</form>
	
	<br></br>

<div class="panel panel-default">
<div class="panel-heading">
    <h4 class="panel-title">
        <a class="btn btn-success btn-lg">PROFIL IDENTITAS</a>
    </h4>
</div>
<div class="panel-body">
  	<table>
  		<img width="100px" src="{{ url('/profil/'.$p->profil) }}">
  		<br><br>

		<tr>
			<td width="175px"><label>NIP</label></td>
			<td width="25px">:</td>
			<td>{{ $p->nip }}</td>
		</tr>
		<tr>
			<td><label>Nama</label></td>
			<td>:</td>
			<td>{{ $p->nama }}</td>
		</tr>
		<tr>
			<td><label>Jenis Kelamin</label></td>
			<td>:</td>
			<td>{{ $p->jenis_kelamin }}</td>
		</tr>
		<tr>
			<td><label>Status</label></td>
			<td>:</td>
			<td>{{ $p->status }}</td>
		</tr>
		<tr>
			<td><label>Agama</label></td>
			<td>:</td>
			<td>{{ $p->agama }}</td>
		</tr>
		<tr>
			<td><label>Alamat</label></td>
			<td>:</td>
			<td>{{ $p->alamat }}</td>
		</tr>
		<tr>
			<td><label>Pendidikan</label></td>
			<td>:</td>
			<td>{{ $p->pendidikan }}</td>
		</tr>
		<tr>
			<td><label>Negara</label></td>
			<td>:</td>
			<td>{{ $p->negara }}</td>
		</tr>
		<tr>
			<td><label>Tempat/Tanggal Lahir</label></td>
			<td>:</td>
			<td>{{ $p->tempat_tanggal_lahir }}</td>
		</tr>
	</table>
</div>
</div>

<div class="panel panel-default">
<div class="panel-heading">
    <h4 class="panel-title">
        <a class="btn btn-success btn-lg">POSISI</a>
    </h4>
</div>
<div class="panel-body"> 
	<table>
		
		<tr>
			<td width="100px"><label>Department</label></td>
			<td width="25px">:</td>
			<td>{{ $p->department }}</td>
		</tr>
		<tr>
			<td><label>Jabatan</label></td>
			<td>:</td>
			<td>{{ $p->jabatan }}</td>
		</tr>
	</table>
</div>
</div>

<div class="panel panel-default">
<div class="panel-heading">
    <h4 class="panel-title">
        <a class="btn btn-success btn-lg">KONTAK</a>
    </h4>
</div>
<div class="panel-body">
<table>
	<tr>
		<td width="50px"><label>No Hp</label></td>
		<td width="25px">:</td>
		<td>{{ $p->no_hp }}</td>
	</tr>
	<tr>
		<td><label>Email</label></td>
		<td>:</td>
		<td>{{ $p->email }}</td>
	</tr>
</table>
</div>
</div>

@endforeach

</div>
</div>
</div>
</div>
</div>
 	